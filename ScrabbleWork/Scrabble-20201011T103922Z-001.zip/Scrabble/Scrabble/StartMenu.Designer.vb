﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class StartMenu
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.EventLog1 = New System.Diagnostics.EventLog()
        Me.Play_Button = New System.Windows.Forms.Button()
        Me.Settings_Button = New System.Windows.Forms.Button()
        Me.Quit_Button = New System.Windows.Forms.Button()
        Me.Leaderboard_Button = New System.Windows.Forms.Button()
        CType(Me.EventLog1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'EventLog1
        '
        Me.EventLog1.SynchronizingObject = Me
        '
        'Play_Button
        '
        Me.Play_Button.Location = New System.Drawing.Point(314, 142)
        Me.Play_Button.Name = "Play_Button"
        Me.Play_Button.Size = New System.Drawing.Size(75, 23)
        Me.Play_Button.TabIndex = 0
        Me.Play_Button.Text = "Play Game"
        Me.Play_Button.UseVisualStyleBackColor = True
        '
        'Settings_Button
        '
        Me.Settings_Button.Location = New System.Drawing.Point(314, 188)
        Me.Settings_Button.Name = "Settings_Button"
        Me.Settings_Button.Size = New System.Drawing.Size(75, 23)
        Me.Settings_Button.TabIndex = 1
        Me.Settings_Button.Text = "Settings"
        Me.Settings_Button.UseVisualStyleBackColor = True
        '
        'Quit_Button
        '
        Me.Quit_Button.Location = New System.Drawing.Point(314, 271)
        Me.Quit_Button.Name = "Quit_Button"
        Me.Quit_Button.Size = New System.Drawing.Size(75, 23)
        Me.Quit_Button.TabIndex = 2
        Me.Quit_Button.Text = "Quit"
        Me.Quit_Button.UseVisualStyleBackColor = True
        '
        'Leaderboard_Button
        '
        Me.Leaderboard_Button.Location = New System.Drawing.Point(314, 231)
        Me.Leaderboard_Button.Name = "Leaderboard_Button"
        Me.Leaderboard_Button.Size = New System.Drawing.Size(75, 23)
        Me.Leaderboard_Button.TabIndex = 3
        Me.Leaderboard_Button.Text = "Leaderboard"
        Me.Leaderboard_Button.UseVisualStyleBackColor = True
        '
        'StartMenu
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(800, 450)
        Me.Controls.Add(Me.Leaderboard_Button)
        Me.Controls.Add(Me.Quit_Button)
        Me.Controls.Add(Me.Settings_Button)
        Me.Controls.Add(Me.Play_Button)
        Me.Name = "StartMenu"
        Me.Text = "Form1"
        CType(Me.EventLog1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents EventLog1 As EventLog
    Friend WithEvents Play_Button As Button
    Friend WithEvents Quit_Button As Button
    Friend WithEvents Settings_Button As Button
    Friend WithEvents Leaderboard_Button As Button
End Class
