﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Game
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Game))
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.Player1_Score = New System.Windows.Forms.Label()
        Me.Player2_Score = New System.Windows.Forms.Label()
        Me.Letter2 = New System.Windows.Forms.PictureBox()
        Me.Letter3 = New System.Windows.Forms.PictureBox()
        Me.Letter4 = New System.Windows.Forms.PictureBox()
        Me.Letter5 = New System.Windows.Forms.PictureBox()
        Me.Letter6 = New System.Windows.Forms.PictureBox()
        Me.Letter7 = New System.Windows.Forms.PictureBox()
        Me.Letter1 = New System.Windows.Forms.PictureBox()
        Me.EndTurn_Button = New System.Windows.Forms.Button()
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Letter2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Letter3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Letter4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Letter5, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Letter6, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Letter7, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Letter1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'PictureBox1
        '
        Me.PictureBox1.BackgroundImage = CType(resources.GetObject("PictureBox1.BackgroundImage"), System.Drawing.Image)
        Me.PictureBox1.Location = New System.Drawing.Point(12, 12)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(600, 600)
        Me.PictureBox1.TabIndex = 0
        Me.PictureBox1.TabStop = False
        '
        'Player1_Score
        '
        Me.Player1_Score.AutoSize = True
        Me.Player1_Score.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Player1_Score.Location = New System.Drawing.Point(644, 82)
        Me.Player1_Score.Name = "Player1_Score"
        Me.Player1_Score.Size = New System.Drawing.Size(94, 29)
        Me.Player1_Score.TabIndex = 2
        Me.Player1_Score.Text = "Player1"
        '
        'Player2_Score
        '
        Me.Player2_Score.AutoSize = True
        Me.Player2_Score.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Player2_Score.Location = New System.Drawing.Point(644, 132)
        Me.Player2_Score.Name = "Player2_Score"
        Me.Player2_Score.Size = New System.Drawing.Size(94, 29)
        Me.Player2_Score.TabIndex = 3
        Me.Player2_Score.Text = "Player2"
        '
        'Letter2
        '
        Me.Letter2.Location = New System.Drawing.Point(100, 634)
        Me.Letter2.Name = "Letter2"
        Me.Letter2.Size = New System.Drawing.Size(75, 75)
        Me.Letter2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.Letter2.TabIndex = 5
        Me.Letter2.TabStop = False
        '
        'Letter3
        '
        Me.Letter3.Location = New System.Drawing.Point(181, 634)
        Me.Letter3.Name = "Letter3"
        Me.Letter3.Size = New System.Drawing.Size(75, 75)
        Me.Letter3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.Letter3.TabIndex = 6
        Me.Letter3.TabStop = False
        '
        'Letter4
        '
        Me.Letter4.Location = New System.Drawing.Point(505, 634)
        Me.Letter4.Name = "Letter4"
        Me.Letter4.Size = New System.Drawing.Size(75, 75)
        Me.Letter4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.Letter4.TabIndex = 7
        Me.Letter4.TabStop = False
        '
        'Letter5
        '
        Me.Letter5.Location = New System.Drawing.Point(424, 634)
        Me.Letter5.Name = "Letter5"
        Me.Letter5.Size = New System.Drawing.Size(75, 75)
        Me.Letter5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.Letter5.TabIndex = 8
        Me.Letter5.TabStop = False
        '
        'Letter6
        '
        Me.Letter6.Location = New System.Drawing.Point(262, 634)
        Me.Letter6.Name = "Letter6"
        Me.Letter6.Size = New System.Drawing.Size(75, 75)
        Me.Letter6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.Letter6.TabIndex = 9
        Me.Letter6.TabStop = False
        '
        'Letter7
        '
        Me.Letter7.Location = New System.Drawing.Point(343, 634)
        Me.Letter7.Name = "Letter7"
        Me.Letter7.Size = New System.Drawing.Size(75, 75)
        Me.Letter7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.Letter7.TabIndex = 10
        Me.Letter7.TabStop = False
        '
        'Letter1
        '
        Me.Letter1.Location = New System.Drawing.Point(12, 634)
        Me.Letter1.Name = "Letter1"
        Me.Letter1.Size = New System.Drawing.Size(75, 75)
        Me.Letter1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.Letter1.TabIndex = 11
        Me.Letter1.TabStop = False
        '
        'EndTurn_Button
        '
        Me.EndTurn_Button.Location = New System.Drawing.Point(607, 634)
        Me.EndTurn_Button.Name = "EndTurn_Button"
        Me.EndTurn_Button.Size = New System.Drawing.Size(131, 75)
        Me.EndTurn_Button.TabIndex = 12
        Me.EndTurn_Button.Text = "End Turn"
        Me.EndTurn_Button.UseVisualStyleBackColor = True
        '
        'Game
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(984, 961)
        Me.Controls.Add(Me.EndTurn_Button)
        Me.Controls.Add(Me.Letter1)
        Me.Controls.Add(Me.Letter7)
        Me.Controls.Add(Me.Letter6)
        Me.Controls.Add(Me.Letter5)
        Me.Controls.Add(Me.Letter4)
        Me.Controls.Add(Me.Letter3)
        Me.Controls.Add(Me.Letter2)
        Me.Controls.Add(Me.Player2_Score)
        Me.Controls.Add(Me.Player1_Score)
        Me.Controls.Add(Me.PictureBox1)
        Me.Name = "Game"
        Me.Text = "Game"
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Letter2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Letter3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Letter4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Letter5, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Letter6, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Letter7, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Letter1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents Player1_Score As Label
    Friend WithEvents Player2_Score As Label
    Friend WithEvents Letter2 As PictureBox
    Friend WithEvents Letter3 As PictureBox
    Friend WithEvents Letter4 As PictureBox
    Friend WithEvents Letter5 As PictureBox
    Friend WithEvents Letter6 As PictureBox
    Friend WithEvents Letter7 As PictureBox
    Friend WithEvents Letter1 As PictureBox
    Friend WithEvents EndTurn_Button As Button
    Friend WithEvents Timer1 As Timer
End Class
