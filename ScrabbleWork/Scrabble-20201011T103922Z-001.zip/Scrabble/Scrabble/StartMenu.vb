﻿Public Class StartMenu
    Private Sub Play_Button_Click(sender As Object, e As EventArgs) Handles Play_Button.Click
        Game.Show() 'Change to PlayMenu later
    End Sub

    Private Sub Settings_Button_Click(sender As Object, e As EventArgs) Handles Settings_Button.Click
        Application.Run(SettingsMenu)
    End Sub

    Private Sub Leaderboard_Button_Click(sender As Object, e As EventArgs) Handles Leaderboard_Button.Click
        Application.Run(LeaderboardMenu)
    End Sub

    Private Sub Quit_Button_Click(sender As Object, e As EventArgs) Handles Quit_Button.Click
        Application.Exit()
    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub


End Class
