﻿Public Class Game
    Private Player1_TotalScore As Integer
    Private Player2_TotalScore As Integer

    Private Player1_Turn As Boolean

    Private Player1_Hand As String
    Private Player2_Hand As String

    Public NewLetterPositions(14, 14) As Char
    Public FinalizedLetterPositions(14, 14) As Char

    Private MovingLetter As Char = " "

    Private PlayedLetters(6) As Char
    Private LetterSelected As Integer

    Public placedLetter(14, 14) As PictureBox

    Private Sub DealLetters(ByVal LettersPlayed As Integer) 'Change to values entered into the SettingsMenu later in development
        'Dim Player1_Hand As String
        'Dim Player2_Hand As String

        Dim HandSize = 7 - LettersPlayed 'Will update after each turn - Subject to change

        Dim Letter() As String = {"A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z", "-"}

        '                       A  B  C  D  E   F  G  H  I  J  K  L  M  N  O  P  Q  R  S  T  U  V  W  X  Y  Z  BLANK
        Dim Bag() As Integer = {9, 2, 2, 4, 12, 2, 3, 2, 9, 1, 1, 4, 2, 6, 8, 2, 1, 6, 4, 6, 4, 2, 2, 1, 2, 1, 2}

        Dim NewBag As String
        Dim NewBagSize As Integer
        Dim BagSize As Integer

        Static Dim rndLetter As New Random()
        Dim NewBagRnd As Integer
        Dim BagRnd As Integer

        Dim PlayerTurn As Integer



        For i = 0 To Bag.Length - 1
            For j = 0 To Bag(i) - 1
                NewBag += Letter(i)
            Next
        Next

        '(NewBag)

        NewBagSize = NewBag.Length
        BagSize = Bag.Length


        For i = 0 To LettersPlayed - 1
            Do
                NewBagRnd = rndLetter.Next(0, NewBagSize - 1)
                BagRnd = rndLetter.Next(0, BagSize - 1)
            Loop Until Bag(BagRnd) <> 0

            Bag(BagRnd) -= 1
            Player1_Hand &= NewBag(NewBagRnd)
        Next

        '!!Need to be differentiated between dependent on which player's turn it is!!

        LettersPlayed = 7

        For i = 0 To LettersPlayed - 1
            Do
                NewBagRnd = rndLetter.Next(0, NewBagSize - 1)
                BagRnd = rndLetter.Next(0, BagSize - 1)
            Loop Until Bag(BagRnd) <> 0

            Bag(BagRnd) -= 1
            Player2_Hand &= NewBag(NewBagRnd)
        Next


        Player1_Turn = DecideFirst(Player1_Hand, Player2_Hand)

        LettersPlayed = 0

        Draw(Player1_Hand, Player2_Hand, PlayerTurn)

        'MsgBox(Player1_Hand & " " & Player2_Hand & " Player" & PlayerTurn)
    End Sub

    Private Function DecideFirst(ByVal Hand1 As String, ByVal Hand2 As String)
        Dim Lowest1 As Integer = Asc(Hand1(0))
        Dim Lowest2 As Integer = Asc(Hand2(0))
        For i = 1 To 6
            If Asc(Hand1(i)) <= Lowest1 Then
                Lowest1 = Asc(Hand1(i))
            ElseIf Asc(Hand2(i)) <= Lowest2 Then
                Lowest2 = Asc(Hand2(i))
            End If
        Next

        'MsgBox(Lowest1 & " " & Lowest2)

        If Lowest1 < Lowest2 Then
            'Player1 goes first
            Return True
        ElseIf Lowest2 = Lowest1 Then
            'Goes to a 50/50 Coinflip
            Static Coin As New Random
            Dim rnd As Integer
            rnd = Coin.Next(0, 2)
            Return rnd
        Else
            'Player2 goes first
            Return False
        End If
    End Function

    Public Sub UpdateScore(ByVal Score As Integer)
        If Player1_Turn Then
            Player1_TotalScore += Score
        Else
            Player2_TotalScore += Score
        End If
    End Sub

    Public Sub Draw(ByVal Player1_Hand As String, ByVal Player2_Hand As String, ByVal PlayerTurn As Integer)

        'myRectangle = New Rectangle(x:=5, y:=5, width:=10, height:=40)

        Dim Letters() As PictureBox = {Letter1, Letter2, Letter3, Letter4, Letter5, Letter6, Letter7}
        Dim PlayersHands() As String = {Player1_Hand, Player2_Hand}

        'MsgBox(Player1_Hand + " " + Player2_Hand)

        'Letter1.Image = Image.FromFile("LetterA.png")

        If Player1_Turn Then
            'If player1's turn it will change the colour of the text to red
            Player1_Score.ForeColor = Color.Red
            Player2_Score.ForeColor = Color.Black

            For i = 0 To 6
                Letters(i).Image = Image.FromFile("Letter" + Player1_Hand(i) + ".png")
            Next
        Else
            'If player2's turn it will change the colour of the text to red
            Player1_Score.ForeColor = Color.Black
            Player2_Score.ForeColor = Color.Red
            For i = 0 To 6
                Letters(i).Image = Image.FromFile("Letter" + Player2_Hand(i) + ".png")
            Next
        End If
    End Sub

    Private Sub Game_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        For x = 0 To 14
            For y = 0 To 14
                NewLetterPositions(x, y) = ""
                FinalizedLetterPositions(x, y) = ""
            Next
        Next

        Player1_TotalScore = 0
        DealLetters(7)
        PictureBox1.SendToBack()
    End Sub

    Private Sub Letter_Select(sender As Object, e As EventArgs) Handles Letter1.Click, Letter2.Click, Letter3.Click, Letter4.Click, Letter5.Click, Letter6.Click, Letter7.Click
        Static Dim Selected As Boolean

        Dim Letters() As Image = {Letter1.Image, Letter2.Image, Letter3.Image, Letter4.Image, Letter5.Image, Letter6.Image, Letter7.Image}

        'Static Dim Original As String = Image.FromStream()

        Dim LetterClicked As PictureBox = DirectCast(sender, PictureBox)

        LetterClicked.Image.Dispose()

        Select Case LetterClicked.Name
            Case "Letter1"
                LetterSelected = 0
            Case "Letter2"
                LetterSelected = 1
            Case "Letter3"
                LetterSelected = 2
            Case "Letter4"
                LetterSelected = 3
            Case "Letter5"
                LetterSelected = 4
            Case "Letter6"
                LetterSelected = 5
            Case "Letter7"
                LetterSelected = 6
        End Select

        'MsgBox(LetterSelected)

        If Selected Then
            Selected = False
            MovingLetter = " "
            If Player1_Turn Then
                LetterClicked.Image = Image.FromFile("Letter" + Player1_Hand(LetterSelected) + ".png")
            Else
                LetterClicked.Image = Image.FromFile("Letter" + Player2_Hand(LetterSelected) + ".png")
            End If

        Else
            Selected = True
            If Player1_Turn Then
                MovingLetter = Player1_Hand(LetterSelected)
            Else
                MovingLetter = Player2_Hand(LetterSelected)
            End If
            LetterClicked.Image = Image.FromFile("LetterSELECT.png")
        End If

        Dim Clicked As Boolean = MouseButtons.HasFlag(MouseButtons.Left)
        If Clicked Then
            'MsgBox("Clicked")
        End If

        'MsgBox(Selected)
    End Sub

    Private Sub CursorPosition()
        Dim CursorPosX = Cursor.Position().X
        Dim CursorPosY = Cursor.Position().Y

        'Limit = 12,572
        'limit (150 - 697, 95 - 695)
        'Grid = 36.333 per tile

    End Sub

    Private Sub MouseDown()
        Dim Clicked As Boolean = MouseButtons.HasFlag(MouseButtons.Left)
        If Clicked Then
            'MsgBox("Clicked")
        End If
    End Sub


    Private Sub PictureBox1_MouseDown(sender As Object, e As MouseEventArgs) Handles PictureBox1.MouseDown
        Dim CursorPosX As Integer = Cursor.Position().X
        Dim CursorPosY As Integer = Cursor.Position().Y

        Dim LetterPositionX() As Integer = {12, 52, 92, 132, 172, 212, 252, 292, 332, 372, 412, 452, 492, 532, 572}
        Dim LetterPositionY() As Integer = {12, 52, 92, 132, 172, 212, 252, 292, 332, 372, 412, 452, 492, 532, 572}

        Dim DifferenceLetterX As Double 'Aligns the coords to the window no matter where it is (Attempt)
        Dim DifferenceLetterY As Double

        Dim Letters() As PictureBox = {Letter1, Letter2, Letter3, Letter4, Letter5, Letter6, Letter7}

        Dim CurrentLetterPositionX As Integer
        Dim CurrentLetterPositionY As Integer

        CurrentLetterPositionX = (CursorPosX - 12) \ 40
        CurrentLetterPositionY = (CursorPosY - 35) \ 40


        'DifferenceLetterX = 0 - CurrentLetterPositionX
        'DifferenceLetterY = 0 - CurrentLetterPositionY

        'Can be used to Add the score of letters later in the program
        '---------------------------------------------------------------------------------------------------------------------------
        'Dim lbl As Label = New Label
        'lbl.Size = New System.Drawing.Size(40, 40)
        'lbl.Location = New System.Drawing.Point(LetterPositionX(CurrentLetterPositionX), LetterPositionY(CurrentLetterPositionY))
        'lbl.Text = "A"
        'lbl.BringToFront()

        'Me.Controls.Add(lbl)
        '---------------------------------------------------------------------------------------------------------------------------

        If NewLetterPositions(CurrentLetterPositionX, CurrentLetterPositionY) = Nothing And FinalizedLetterPositions(CurrentLetterPositionX, CurrentLetterPositionY) = Nothing Then

            If MovingLetter <> " " Then

                Dim picturebox As New PictureBox
                picturebox.Name = Str(CurrentLetterPositionX) + "," + Str(CurrentLetterPositionY)
                picturebox.SizeMode = PictureBoxSizeMode.StretchImage
                picturebox.Image = System.Drawing.Bitmap.FromFile(My.Computer.FileSystem.GetName("Letter" + MovingLetter + ".png"))
                picturebox.Location = New Point(LetterPositionX(CurrentLetterPositionX), LetterPositionY(CurrentLetterPositionY))
                picturebox.Width = 40
                picturebox.Height = 40
                picturebox.Visible = True
                AddHandler picturebox.Click, AddressOf PictureBox1_MouseDown 'Crucial for allowing the program to access the boad (behind the placed letters)
                Me.Controls.Add(picturebox)
                picturebox.BringToFront()

                'MsgBox(Str(CurrentLetterPositionX) + "" + Str(CurrentLetterPositionY))

                Current_Board(MovingLetter, CurrentLetterPositionX, CurrentLetterPositionY)

                PlayedLetters(LetterSelected) = MovingLetter

                Letters(LetterSelected).Visible = False

                placedLetter(CurrentLetterPositionX, CurrentLetterPositionY) = picturebox

                'Removes the letter in the hand once it is placed 

                Replace(Player1_Hand, MovingLetter, "")
            Else

            End If

        ElseIf Not NewLetterPositions(CurrentLetterPositionX, CurrentLetterPositionY) = Nothing Then

            placedLetter(CurrentLetterPositionX, CurrentLetterPositionY).Visible = False
            placedLetter(CurrentLetterPositionX, CurrentLetterPositionY) = Nothing
            placedLetter(CurrentLetterPositionX, CurrentLetterPositionY) = Nothing

        End If


        'MsgBox(Str(CurrentLetterPositionX) + " " + Str(CurrentLetterPositionY))

        '12,611

        'pwetty colours

    End Sub


    Public Class Board

        Public ExactFinalizedCoords(572, 572) As Char
        Public ExactNewCoords(572, 572) As Char

        Public NewLetterPositions(14, 14) As Char
        Public FinalizedLetterPositions(14, 14) As Char

    End Class


    Sub TurnOver_Board(ByRef Letter As Char, ByRef X As Integer, ByRef Y As Integer)

        Dim SetBoard As Board

        FinalizedLetterPositions(X, Y) = Letter

    End Sub

    Sub Current_Board(ByRef Letter As Char, ByRef X As Integer, ByRef Y As Integer)
        Dim SetBoard As Board

        NewLetterPositions(X, Y) = MovingLetter
    End Sub

    Sub TurnEnd()

        Dim board As Board
        Dim Valid As Boolean

        Valid = IsValid()

        If Valid Then
            'Adds the letters to the final board layout (Will be done if the isValid is true
            For x = 0 To board.NewLetterPositions.Length - 1
                For y = 0 To board.NewLetterPositions.Length - 1
                    If board.NewLetterPositions(x, y) <> "" Then
                        board.FinalizedLetterPositions(x, y) = board.NewLetterPositions(x, y)
                    End If
                Next
            Next

            Array.Clear(board.NewLetterPositions, 0, board.NewLetterPositions.Length)
        Else

        End If

    End Sub


    Public Class SurroundingLetters

    End Class

    Function IsValid() 'Will be called after 'End Turn' button is clicked
        'First step is checking whether it is in a legal position
        Dim board As Board

        Dim LetterInY As Boolean
        Dim LetterInX As Boolean

        Dim Connected As Boolean = False
        Dim ValidWord As Boolean
        Dim SameWord As Boolean = False

        Dim word As String
        Dim Letter As Char

        Dim i As Integer = 0

        'Checks X and Y to see if the new letter is in the same axis as another
        For x = 0 To 14

            Dim LettersInXCount As Integer

            Dim LettersInYCount As Integer

            For y = 0 To 14
                'At the moment it does not count single letters added on to previous words
                If NewLetterPositions(x, y) <> "" Then
                    LettersInXCount += 1
                    LettersInYCount += 1
                End If
                If LettersInXCount > 1 Then
                    LetterInX = True
                End If
                If LettersInYCount > 1 Then
                    LetterInY = True
                End If
                LettersInYCount = 0
                'Now I have to check whether the the letter is adjacent to another





                'Now I have to determine the validity of a word
                'I have to create a rough grid with all letters so I can compare everything 
                If FinalizedLetterPositions(x, y) = Nothing And NewLetterPositions(x, y) = Nothing And SameWord Then
                    'Checks that there aren't any single letter words (illegal play)
                    If word.Length > 1 Then
                        Dim check = Dictionary(word)
                        MsgBox(word + " " + Str(check))
                        word = ""
                        SameWord = False
                    Else Return False
                    End If
                ElseIf FinalizedLetterPositions(x, y) = Nothing And NewLetterPositions(x, y) = Nothing Then
                    SameWord = False
                ElseIf NewLetterPositions(x, y) <> "" Then
                    word = word & NewLetterPositions(x, y)
                    SameWord = True
                ElseIf FinalizedLetterPositions(x, y) <> "" Then
                    word = word & Str(FinalizedLetterPositions(x, y))
                    SameWord = True
                End If

                'If Not Connected Then
                '    Return False
                'Else

                'End If
            Next

            SameWord = False

            LettersInXCount = 0
        Next

        For y = 0 To 14

            For x = 0 To 14
                If FinalizedLetterPositions(x, y) = Nothing And NewLetterPositions(x, y) = Nothing And SameWord Then
                    Dim check = Dictionary(word)
                    MsgBox(word + " " + Str(check))
                    word = ""
                    SameWord = False
                ElseIf FinalizedLetterPositions(x, y) = Nothing And NewLetterPositions(x, y) = Nothing Then
                    SameWord = False
                ElseIf NewLetterPositions(x, y) <> "" Then
                    word = word & NewLetterPositions(x, y)
                    SameWord = True
                ElseIf FinalizedLetterPositions(x, y) <> "" Then
                    word = word & Str(FinalizedLetterPositions(x, y))
                    SameWord = True

                End If
            Next

        Next

        If LetterInX Or LetterInY Then

        Else
            Return False
        End If

    End Function

    Function Dictionary(ByRef word As String)

        Dim FileReader As System.IO.StreamReader
        FileReader = My.Computer.FileSystem.OpenTextFileReader("ScrabbleWords.txt")
        Dim stringReader As String
        Dim words(276643) As String

        For i = 0 To words.Length - 1
            words(i) = FileReader.ReadLine
            If words(i) = word Then
                Return True
            End If
        Next
        Return False

    End Function


    Function FindScore()

    End Function

    Private Sub EndTurn_Button_Click(sender As Object, e As EventArgs) Handles EndTurn_Button.Click

        IsValid()
        TurnEnd()

    End Sub



End Class